class CartIsEmptyException(Exception):
    pass

class AmountInvalidException(Exception):
    pass
